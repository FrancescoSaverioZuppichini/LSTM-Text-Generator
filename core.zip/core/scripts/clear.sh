#!/bin/bash

rm *.out && rm *.err