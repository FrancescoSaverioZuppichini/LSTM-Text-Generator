#!/bin/bash
while :
do
	clear
	squeue
	sleep 1

done