sbatch ./scripts/main.sh && ./scripts/squeue_interactive.sh
