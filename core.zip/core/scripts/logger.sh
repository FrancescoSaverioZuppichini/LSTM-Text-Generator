#!/bin/bash
while :
do
	cat $1
	sleep 1

done
